<?php
session_start();
include 'db_connect.php';  // เชื่อมต่อกับฐานข้อมูล

if (isset($_POST['login'])) {
    $hash = $_POST['hash'];         // รับค่าจากฟอร์ม input ที่เป็น hash
    $password = $_POST['password']; // รับรหัสผ่านจากฟอร์ม

    // ตรวจสอบว่ามี hash นี้ในฐานข้อมูลหรือไม่
    $query = "SELECT * FROM teachers WHERE hash = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $hash);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // ดึงข้อมูลครูที่ตรงกับ hash ที่ป้อนมา
        $teacher = $result->fetch_assoc();

        // ตรวจสอบรหัสผ่าน
        if (password_verify($password, $teacher['password'])) {
            // หากรหัสผ่านถูกต้อง เก็บ hash ใน session
            $_SESSION['teacher_hash'] = $teacher['hash'];
            header("Location: index.php");  // เปลี่ยนไปหน้า dashboard
            exit();
        } else {
            $error = "Invalid password.";
        }
    } else {
        $error = "User not found.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="login-container">
        
        <h2>Teacher Login</h2>

        <!-- แสดงข้อความผิดพลาดหากมี -->
        <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>

        <form action="login.php" method="post">
            <label for="hash">Hash (Teacher's unique ID):</label>
            <input type="text" id="hash" name="hash" required placeholder="Enter Teacher Hash">

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required placeholder="Enter Password">

            <button type="submit" name="login">Login</button>
        </form>

        <p><a href="register_teacher.php">Register as a new Teacher</a></p>
    </div>
</body>
</html>
