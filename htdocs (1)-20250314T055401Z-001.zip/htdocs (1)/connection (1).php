<?php
$servername = "localhost";
$username = "root";
$password= "";
$dbname = "blockchain";

$connect = mysqli_connect($servername,$username,$password,$dbname);
// $con = mysqli_select_db($connect,$dbname);


	
	
?>